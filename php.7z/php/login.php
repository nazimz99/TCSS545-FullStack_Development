<?php
    phpinfo();
?>
<?php
require_once("connect.php");
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: database.html");
    exit;
}

// Include config file
require_once "connect.php";
if ($_SERVER['REQUEST_METHOD'] == 'POST' || isset($_POST["submit"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $sql = "SELECT * 
            FROM User 
            WHERE Username = '".$username."' AND Password='".$password."'
            limit 1";
    $result = mysqli_query($db, $sql);

    if (mysqli_num_rows($result) == 1) {
        echo "You have successfully logged in";
        header("location: database.html");
        exit();
    }
    else 
        echo "You have entered an invalid username or password.";
        exit();
} 
   // Close connection
    mysqli_close($db);

?>