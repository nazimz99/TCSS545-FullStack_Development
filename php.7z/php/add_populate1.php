<?php
    require_once("connect.php");

    $State = $_POST["state"];
    $NumOfPeople = $_POST["numofpeople"];
    $PopDensity = $_POST["pop_density"];
    $CaseDensity = $_POST["case_density"];
    $DeathDensity = $_POST["death_density"];
    $TestsDensity = $_POST["test_density"];
    $sql = "INSERT INTO Population(State, NumOfPeople, Capita, CaseDensity, DeathDensity, TestsDensity) VALUES
            ('$State', $NumOfPeople, $PopDensity, $CaseDensity, $DeathDensity, $TestsDensity)";
    $assertion = "CREATE ASSERTION NoPopulation
                  CHECK (
                  EXISTS (SELECT State FROM Population)";
    $result = mysqli_query($db, $assertion);
    if (empty($State) || empty($NumOfPeople) || empty($PopDensity) || empty($CaseDensity) || empty($DeathDensity) || empty($TestsDensity))
        echo "Please enter a value in every field.";
    else if ($result != FALSE) {
        echo "The state already exists. To modify, delete and enter query. Else, add valid state.";
    }
    else {
        if (mysqli_query($db, $sql)) {
		  echo "New record created successfully";
		} else {
		  echo "Error: " . $sql . "<br>" . mysqli_error($db);
		}

    }
    mysqli_close($db);
?>